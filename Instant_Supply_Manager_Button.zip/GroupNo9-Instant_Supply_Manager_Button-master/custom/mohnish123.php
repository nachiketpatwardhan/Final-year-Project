<?php
$usern='username';
header("Location:orders/cinvoice.php?tot=".$usern);
?>
